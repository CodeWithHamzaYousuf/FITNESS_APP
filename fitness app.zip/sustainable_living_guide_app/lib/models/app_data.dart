import 'package:flutter/material.dart';

class AppData {
  static final List<Map<String, dynamic>> homeModules = [
    {'title': 'Carbon Footprint Tracker', 'icon': Icons.cloud_off, 'screen': 'Trackers'},
    {'title': 'Waste Reduction Tracker', 'icon': Icons.delete_sweep, 'screen': 'Trackers'},
    {'title': 'Eco-Friendly Product Suggestions', 'icon': Icons.shopping_bag, 'screen': 'Suggestions'},
    {'title': 'Sustainable Living Challenges', 'icon': Icons.star, 'screen': 'Challenges'},
    {'title': 'Green Certifications & Labels Guide', 'icon': Icons.verified_user, 'screen': 'Education'},
    {'title': 'Sustainable Recipes & Meal Planning', 'icon': Icons.restaurant_menu, 'screen': 'Recipes'},
    {'title': 'Energy Conservation Tips', 'icon': Icons.lightbulb, 'screen': 'Education'},
    {'title': 'Eco-Travel Suggestions', 'icon': Icons.flight_takeoff, 'screen': 'Suggestions'},
    {'title': 'Community Forum & Support', 'icon': Icons.people, 'screen': 'Community'},
    {'title': 'Sustainability Progress Dashboard', 'icon': Icons.dashboard, 'screen': 'Trackers'},
    {'title': 'Educational Content', 'icon': Icons.school, 'screen': 'Education'},
  ];

  static final List<Map<String, dynamic>> educationalContent = [
    {'title': 'The Basics of Carbon Footprint', 'type': 'Article', 'content': 'A detailed article on how to calculate and reduce your carbon footprint...'},
    {'title': 'Top 10 Eco-Friendly Products', 'type': 'Video', 'content': 'A video showcasing the best sustainable products for your home...'},
    {'title': 'Understanding Fair Trade Labels', 'type': 'Infographic', 'content': 'An infographic explaining what the Fair Trade certification means...'},
    {'title': 'How to Start Composting', 'type': 'Article', 'content': 'Step-by-step guide to setting up a home composting system...'},
  ];

  static final List<Map<String, dynamic>> productSuggestions = [
    {'name': 'Reusable Water Bottle', 'category': 'Zero-Waste', 'description': 'A durable stainless steel bottle.'},
    {'name': 'Bamboo Toothbrush', 'category': 'Personal Care', 'description': 'An eco-friendly alternative to plastic.'},
    {'name': 'Energy Star Refrigerator', 'category': 'Appliances', 'description': 'Highly energy-efficient model.'},
    {'name': 'Organic Cotton T-Shirt', 'category': 'Apparel', 'description': 'Made from sustainably sourced cotton.'},
  ];

  static final List<Map<String, dynamic>> challenges = [
    {'name': 'Plastic-Free Week', 'duration': '7 Days', 'description': 'Avoid all single-use plastics for a week.'},
    {'name': 'Meatless Monday', 'duration': 'Weekly', 'description': 'Go vegetarian every Monday.'},
    {'name': 'Energy Saver Month', 'duration': '30 Days', 'description': 'Reduce your home energy consumption by 10%.'},
  ];

  static final List<Map<String, dynamic>> recipes = [
    {'name': 'Lentil Soup', 'type': 'Plant-Based', 'description': 'A hearty, low-carbon footprint soup.'},
    {'name': 'Local Vegetable Stir-fry', 'type': 'Locally Sourced', 'description': 'Use seasonal, local vegetables.'},
  ];

  static final List<String> galleryImages = [
    'Sustainable City',
    'Recycling Bins',
    'Solar Panels',
    'Organic Farm',
    'Electric Car',
    'Composting'
  ];
}

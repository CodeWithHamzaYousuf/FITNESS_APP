import 'package:flutter/material.dart';
import '../models/app_data.dart';

class ChallengesScreen extends StatelessWidget {
  const ChallengesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sustainable Living Challenges'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: AppData.challenges.length,
        itemBuilder: (context, index) {
          final challenge = AppData.challenges[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: const Icon(Icons.star_border, color: Colors.orange),
              title: Text(challenge['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${challenge['duration']} - ${challenge['description']}'),
              trailing: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Joined ${challenge['name']}!')),
                  );
                },
                child: const Text('Join'),
              ),
            ),
          );
        },
      ),
    );
  }
}

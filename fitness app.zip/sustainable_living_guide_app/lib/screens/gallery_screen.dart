import 'package:flutter/material.dart';
import '../models/app_data.dart';

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Gallery'),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: AppData.galleryImages.length,
        itemBuilder: (context, index) {
          return Card(
            clipBehavior: Clip.antiAlias,
            child: GridTile(
              footer: GridTileBar(
                backgroundColor: Colors.black54,
                title: Text(AppData.galleryImages[index]),
                subtitle: const Text('Sustainable Living'),
              ),
              child: Center(
                child: Text(
                  AppData.galleryImages[index],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ), // Placeholder for actual image
            ),
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../models/app_data.dart';

class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false, // Hide back button for bottom nav screens
          title: const Text('Education & Guides'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Educational Content', icon: Icon(Icons.article)),
              Tab(text: 'Green Certifications', icon: Icon(Icons.verified_user)),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            EducationalContentList(),
            GreenCertificationsGuide(),
          ],
        ),
      ),
    );
  }
}

class EducationalContentList extends StatelessWidget {
  const EducationalContentList({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: AppData.educationalContent.length,
      itemBuilder: (context, index) {
        final content = AppData.educationalContent[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: Icon(
              content['type'] == 'Article' ? Icons.description : Icons.videocam,
              color: Colors.blue,
            ),
            title: Text(content['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(content['type'] as String),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Viewing ${content['title']}')),
              );
            },
          ),
        );
      },
    );
  }
}

class GreenCertificationsGuide extends StatelessWidget {
  const GreenCertificationsGuide({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: const [
        Text(
          'Guide to Green Certifications and Labels',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 15),
        ListTile(
          leading: Icon(Icons.eco, color: Colors.green),
          title: Text('Fair Trade'),
          subtitle: Text('Ensures fair wages and safe working conditions for producers.'),
        ),
        ListTile(
          leading: Icon(Icons.flash_on, color: Colors.orange),
          title: Text('Energy Star'),
          subtitle: Text('Identifies energy-efficient products and homes.'),
        ),
        ListTile(
          leading: Icon(Icons.local_florist, color: Colors.brown),
          title: Text('Organic'),
          subtitle: Text('Products grown without synthetic pesticides or fertilizers.'),
        ),
        ListTile(
          leading: Icon(Icons.recycling, color: Colors.blue),
          title: Text('FSC (Forest Stewardship Council)'),
          subtitle: Text('Certifies that wood products come from responsibly managed forests.'),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import '../models/app_data.dart';

class RecipesScreen extends StatelessWidget {
  const RecipesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sustainable Recipes & Meal Planning'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: AppData.recipes.length,
        itemBuilder: (context, index) {
          final recipe = AppData.recipes[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: const Icon(Icons.restaurant, color: Colors.brown),
              title: Text(recipe['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${recipe['type']} - ${recipe['description']}'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Viewing recipe for ${recipe['name']}')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

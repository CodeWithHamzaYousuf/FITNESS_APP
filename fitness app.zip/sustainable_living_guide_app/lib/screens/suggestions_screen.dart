import 'package:flutter/material.dart';
import '../models/app_data.dart';

class SuggestionsScreen extends StatelessWidget {
  const SuggestionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Eco-Friendly Suggestions'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Eco-Friendly Product Suggestions',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ...AppData.productSuggestions.map((product) => Card(
            child: ListTile(
              leading: const Icon(Icons.check_circle_outline, color: Colors.green),
              title: Text(product['name'] as String),
              subtitle: Text('${product['category']} - ${product['description']}'),
            ),
          )).toList(),
          const SizedBox(height: 20),
          const Text(
            'Eco-Travel Suggestions',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const ListTile(
            leading: Icon(Icons.directions_bus, color: Colors.blue),
            title: Text('Use Public Transportation'),
            subtitle: Text('Reduces carbon emissions significantly.'),
          ),
          const ListTile(
            leading: Icon(Icons.car_rental, color: Colors.blue),
            title: Text('Carpooling'),
            subtitle: Text('Share rides to reduce the number of cars on the road.'),
          ),
          const ListTile(
            leading: Icon(Icons.hotel, color: Colors.blue),
            title: Text('Sustainable Hotels'),
            subtitle: Text('Choose accommodations with green certifications.'),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Hide back button for bottom nav screens
        title: const Text('Community Forum & Support'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Share Your Sustainability Journey',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Text('U1')),
              title: const Text('Success with Plastic-Free Week!'),
              subtitle: const Text('User 1: Just finished the challenge, it was tough but rewarding!'),
              trailing: const Icon(Icons.comment),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Text('U2')),
              title: const Text('Best Composting Tips?'),
              subtitle: const Text('User 2: My compost is too wet, any advice?'),
              trailing: const Icon(Icons.comment),
              onTap: () {},
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Opening New Post Editor (Mock)')),
              );
            },
            icon: const Icon(Icons.add),
            label: const Text('Start a New Discussion'),
          ),
        ],
      ),
    );
  }
}

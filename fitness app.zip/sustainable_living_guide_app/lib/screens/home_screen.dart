import 'package:flutter/material.dart';
import '../models/app_data.dart';
import 'trackers_screen.dart';
import 'education_screen.dart';
import 'community_screen.dart';
import 'suggestions_screen.dart';
import 'challenges_screen.dart';
import 'recipes_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _searchQuery = '';
  List<Map<String, dynamic>> _filteredModules = AppData.homeModules;

  void _filterModules(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _filteredModules = AppData.homeModules;
      } else {
        _filteredModules = AppData.homeModules
            .where((module) =>
                (module['title'] as String).toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  Widget _getScreen(String screenName) {
    switch (screenName) {
      case 'Trackers':
        return const TrackersScreen();
      case 'Education':
        return const EducationScreen();
      case 'Community':
        return const CommunityScreen();
      case 'Suggestions':
        return const SuggestionsScreen();
      case 'Challenges':
        return const ChallengesScreen();
      case 'Recipes':
        return const RecipesScreen();
      default:
        return const Center(child: Text('Screen Not Found'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: _filterModules,
                  decoration: const InputDecoration(
                    labelText: 'Search Modules',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.sort),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sort/Filter functionality placeholder')),
                  );
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(10.0),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10.0,
              mainAxisSpacing: 10.0,
              childAspectRatio: 1.2,
            ),
            itemCount: _filteredModules.length,
            itemBuilder: (context, index) {
              final module = _filteredModules[index];
              return Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => _getScreen(module['screen'] as String)),
                    );
                  },
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        module['icon'] as IconData,
                        size: 40,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(
                          module['title'] as String,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

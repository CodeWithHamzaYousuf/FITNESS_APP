import 'package:flutter/material.dart';

class TrackersScreen extends StatelessWidget {
  const TrackersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false, // Hide back button for bottom nav screens
          title: const Text('Trackers & Dashboard'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Carbon Footprint', icon: Icon(Icons.cloud_off)),
              Tab(text: 'Waste Reduction', icon: Icon(Icons.delete_sweep)),
              Tab(text: 'Dashboard', icon: Icon(Icons.dashboard)),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            CarbonFootprintTracker(),
            WasteReductionTracker(),
            ProgressDashboard(),
          ],
        ),
      ),
    );
  }
}

class CarbonFootprintTracker extends StatelessWidget {
  const CarbonFootprintTracker({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Calculate Your Carbon Footprint',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text('Transportation (e.g., miles driven, flights):'),
          const TextField(decoration: InputDecoration(hintText: 'Enter data')),
          const SizedBox(height: 10),
          const Text('Energy Usage (e.g., kWh used):'),
          const TextField(decoration: InputDecoration(hintText: 'Enter data')),
          const SizedBox(height: 10),
          const Text('Food Consumption (e.g., meat servings):'),
          const TextField(decoration: InputDecoration(hintText: 'Enter data')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Carbon Footprint Calculated! (Mock)')),
              );
            },
            child: const Text('Calculate Footprint'),
          ),
          const SizedBox(height: 30),
          const Text(
            'Your Current Footprint: 5.2 tons CO2e/year (Mock Data)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.red),
          ),
          const Text('Recommendation: Reduce red meat consumption and use public transport.'),
        ],
      ),
    );
  }
}

class WasteReductionTracker extends StatelessWidget {
  const WasteReductionTracker({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Track Your Waste Reduction Efforts',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text('Single-Use Plastics Avoided This Week:'),
          const TextField(decoration: InputDecoration(hintText: 'Enter number')),
          const SizedBox(height: 10),
          const Text('Composting Frequency:'),
          const TextField(decoration: InputDecoration(hintText: 'e.g., 3 times a week')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Waste Reduction Logged! (Mock)')),
              );
            },
            child: const Text('Log Waste Reduction'),
          ),
          const SizedBox(height: 30),
          const Text(
            'Total Waste Reduced: 15% improvement this month (Mock Data)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
          ),
          const Text('Tip: Try a plastic-free challenge from the Challenges section!'),
        ],
      ),
    );
  }
}

class ProgressDashboard extends StatelessWidget {
  const ProgressDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Sustainability Progress Dashboard\n(Mock Chart/Stats will be here)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 16),
      ),
    );
  }
}

package com.example.sustainable_living_guide_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
